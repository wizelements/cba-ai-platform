export const projects = [
  {
    title: "One-Page Checkout App",
    description: "Stripe-powered checkout experience with upsell logic.",
    stack: ["Next.js", "Stripe", "Tailwind"]
  },
  // Add more projects here
];